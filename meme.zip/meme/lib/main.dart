import 'package:flutter/material.dart';
import 'screen/auth/auth.dart';

void main() => runApp(new Meme());

class Meme extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: new LoginPage(),
      theme: new ThemeData(primarySwatch: Colors.blue),
    );
  }
}
