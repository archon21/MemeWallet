import 'package:flutter/material.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

class LoginPage extends StatefulWidget {
  @override
  State createState() => new LoginPageState();
}


class LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.red,
      // body: StreamBuilder(
      //   stream: Firestore.instance.collection('users').snapshots(),
      //   builder: (context, snapshot) {
      //     if (!snapshot.hasData) return const Text('Loading');
      //     return new Column(
      //       children: <Widget>[
      //         new Text(snapshot.data.documents[0]['fname']),
      //       ],
      //     );
      //   },
      // ));
      body: new Stack(
        children: <Widget>[
          new Form(
            child: new Theme(
              data: new ThemeData(
                  brightness: Brightness.dark,
                  primarySwatch: Colors.red,
                  inputDecorationTheme: new InputDecorationTheme(
                      labelStyle:
                          new TextStyle(color: Colors.red, fontSize: 20.0))),
              child: new Container(
                padding: const EdgeInsets.all(40.0),
                child: new Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    new Image(
                      image: new AssetImage('assets/wallet.png'),
                      fit: BoxFit.cover,
                      width: 200.0,
                    ),
                    new TextFormField(
                      decoration: new InputDecoration(hintText: 'Email'),
                      keyboardType: TextInputType.emailAddress,
                    ),
                    new TextFormField(
                      decoration: new InputDecoration(hintText: 'Password'),
                      keyboardType: TextInputType.text,
                      obscureText: true,
                    ),
                    new Padding(
                      padding: const EdgeInsets.only(top: 20.0),
                    ),
                    new MaterialButton(
                      color: Colors.black12,
                      textColor: Colors.white,
                      child: new Text('Login'),
                      onPressed: () => {},
                    )
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
